#!/bin/bash

# MySQL 连接配置
MYSQL_HOST="localhost"
MYSQL_PORT="3306"
MYSQL_USER="root"
MYSQL_PASS="root123"

# 数据库名
DB_NAME="foodie_order"

echo "正在创建数据库和表..."
mysql -h${MYSQL_HOST} -P${MYSQL_PORT} -u${MYSQL_USER} -p${MYSQL_PASS} < src/main/resources/db/init.sql

echo "初始化完成！"
