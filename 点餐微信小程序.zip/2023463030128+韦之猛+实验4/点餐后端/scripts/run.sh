# 编译项目
mvn clean package -DskipTests

# 运行项目
java -jar target/order-service-1.0.0.jar
