-- 初始化数据库脚本
-- 包含 foodie_order 表结构 + wxshop 菜品数据

CREATE DATABASE IF NOT EXISTS foodie_order DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE foodie_order;

-- ----------------------------
-- 表结构
-- ----------------------------

-- 用户表
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `openid` VARCHAR(100) NOT NULL COMMENT '微信openid',
    `nickname` VARCHAR(50) DEFAULT NULL COMMENT '昵称',
    `avatar_url` VARCHAR(255) DEFAULT NULL COMMENT '头像',
    `phone` VARCHAR(20) DEFAULT NULL COMMENT '手机号',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted` TINYINT DEFAULT 0,
    UNIQUE KEY `uk_openid` (`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 分类表
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL COMMENT '分类名称',
    `icon` VARCHAR(255) DEFAULT NULL COMMENT '图标',
    `sort` INT DEFAULT 0 COMMENT '排序',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `deleted` TINYINT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分类表';

-- 菜品表
DROP TABLE IF EXISTS `food`;
CREATE TABLE `food` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `category_id` BIGINT NOT NULL COMMENT '分类ID',
    `name` VARCHAR(100) NOT NULL COMMENT '菜品名称',
    `description` VARCHAR(500) DEFAULT NULL COMMENT '描述',
    `price` DECIMAL(10,2) NOT NULL COMMENT '价格',
    `image` VARCHAR(255) DEFAULT NULL COMMENT '图片',
    `stock` INT DEFAULT 0 COMMENT '库存',
    `status` TINYINT DEFAULT 1 COMMENT '状态 0:下架 1:上架',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `deleted` TINYINT DEFAULT 0,
    KEY `idx_category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='菜品表';

-- 促销表
DROP TABLE IF EXISTS `promotion`;
CREATE TABLE `promotion` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(100) NOT NULL COMMENT '标题',
    `image` VARCHAR(255) DEFAULT NULL COMMENT '图片',
    `link` VARCHAR(255) DEFAULT NULL COMMENT '链接',
    `status` TINYINT DEFAULT 1 COMMENT '状态 0:禁用 1:启用',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `deleted` TINYINT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='促销表';

-- 订单表
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `order_no` VARCHAR(50) NOT NULL COMMENT '订单号',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `total_price` DECIMAL(10,2) NOT NULL COMMENT '总价',
    `status` TINYINT DEFAULT 0 COMMENT '状态 0:待支付 1:已支付 2:已取消 3:已完成',
    `comment` VARCHAR(500) DEFAULT NULL COMMENT '备注',
    `pay_time` DATETIME DEFAULT NULL COMMENT '支付时间',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted` TINYINT DEFAULT 0,
    UNIQUE KEY `uk_order_no` (`order_no`),
    KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- 订单项表
DROP TABLE IF EXISTS `order_item`;
CREATE TABLE `order_item` (
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `order_id` BIGINT NOT NULL COMMENT '订单ID',
    `food_id` BIGINT NOT NULL COMMENT '菜品ID',
    `food_name` VARCHAR(100) NOT NULL COMMENT '菜品名称',
    `quantity` INT NOT NULL COMMENT '数量',
    `price` INT NOT NULL COMMENT '单价(分)',
    `deleted` TINYINT DEFAULT 0,
    KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单项表';

-- ----------------------------
-- 分类数据（9个分类，来源 wxshop）
-- ----------------------------
INSERT INTO `category` (`name`, `icon`, `sort`) VALUES
('热销推荐', '/images/1.jpg', 1),
('特色小吃', '/images/17.jpg', 2),
('甜粥', '/images/21.jpg', 3),
('凉菜', '/images/29.jpg', 4),
('醇香奶茶', '/images/30.webp', 5),
('主食', '/images/49.jpg', 6),
('小炒菜', '/images/51.jpg', 7),
('现磨咖啡', '/images/58.webp', 8),
('鲜果奶茶', '/images/73.webp', 9);

-- ----------------------------
-- 菜品数据（81道菜品，来源 wxshop）
-- 图片路径说明：
-- 所有图片放在后端 src/main/resources/static/images/ 目录
-- 通过 http://localhost:8080/images/xxx 访问
-- 小程序访问时 baseUrl + /images/xxx
-- ----------------------------
INSERT INTO `food` (`category_id`, `name`, `description`, `price`, `image`, `stock`, `status`) VALUES
-- 热销推荐 (category_id = 1)
(1, '奶香糯玉米松饼', '松软香甜', 14.00, 'images/1.jpg', 100, 1),
(1, '鲜枣馍', '香甜可口', 13.00, 'images/2.jpg', 100, 1),
(1, '华夫饼', '外酥里嫩', 12.00, 'images/3.jpg', 100, 1),
(1, '琥珀珍珠奶茶（中杯）', 'Q弹珍珠', 10.00, 'images/4.webp', 100, 1),
(1, '香柠咖啡（大杯）', '柠檬清香', 14.00, 'images/5.webp', 100, 1),
(1, '柠檬椰果养乐多/大杯', '酸甜清爽', 17.00, 'images/6.webp', 100, 1),
(1, '芒果养乐多/大杯', '芒果香浓', 16.00, 'images/7.webp', 100, 1),
(1, '葡萄柚养乐多/大杯', '清新果香', 18.00, 'images/8.webp', 100, 1),
(1, '绿茶养乐多/大杯', '绿茶清香', 14.00, 'images/9.webp', 100, 1),
(1, '加10元得冷饮杯', '优惠活动', 10.00, 'images/10.webp', 100, 1),
(1, '红茶拿铁/大杯', '香浓顺滑', 14.00, 'images/11.webp', 100, 1),
(1, '珍珠红茶拿铁/大杯', 'Q弹珍珠', 14.00, 'images/12.webp', 100, 1),
(1, '鲜醇牛奶三兄弟/中杯', '奶香浓郁', 14.00, 'images/13.webp', 100, 1),
(1, '鲜醇草莓欧蕾/中杯', '草莓香甜', 14.00, 'images/14.webp', 100, 1),
(1, '鲜醇芒果欧蕾/中杯', '芒果香浓', 12.00, 'images/15.webp', 100, 1),
(1, '铁观音茶拿铁珍珠/大杯', '茶香四溢', 15.00, 'images/16.webp', 100, 1),

-- 特色小吃 (category_id = 2)
(2, '南瓜荷叶饼', '清香软糯', 13.00, 'images/17.jpg', 100, 1),
(2, '鲜枣馍', '香甜可口', 12.00, 'images/18.jpg', 100, 1),
(2, '芝士火腿包', '芝士浓郁', 10.00, 'images/19.jpg', 100, 1),
(2, '华夫饼', '外酥里嫩', 10.00, 'images/20.jpg', 100, 1),

-- 甜粥 (category_id = 3)
(3, '红豆薏米紫米粥', '养生甜粥', 15.00, 'images/21.jpg', 100, 1),
(3, '枸杞酒酿玉米羹', '香甜软糯', 14.00, 'images/22.jpg', 100, 1),
(3, '红豆桂圆银耳羹/大份', '美容养颜', 14.00, 'images/23.jpg', 100, 1),
(3, '红豆桂圆银耳羹/小份', '美容养颜', 11.00, 'images/24.jpg', 100, 1),
(3, '冬瓜酥肉汤/大份', '清爽鲜美', 14.00, 'images/25.jpg', 100, 1),
(3, '冬瓜酥肉汤/小份', '清爽鲜美', 11.00, 'images/26.jpg', 100, 1),
(3, '土豆炖豆腐/大份', '家常美味', 14.00, 'images/27.jpg', 100, 1),
(3, '土豆炖豆腐/小份', '家常美味', 11.00, 'images/28.jpg', 100, 1),

-- 凉菜 (category_id = 4)
(4, '口水鸡', '麻辣鲜香', 12.00, 'images/29.jpg', 100, 1),

-- 醇香奶茶 (category_id = 5)
(5, '鲜芋奶茶/中杯', '芋香浓郁', 11.00, 'images/30.webp', 100, 1),
(5, '珍珠奶茶/大杯', '经典口味', 11.00, 'images/31.webp', 100, 1),
(5, '珍珠奶茶/中杯', '经典口味', 9.00, 'images/32.webp', 100, 1),
(5, '布丁奶茶/大杯', '嫩滑布丁', 11.00, 'images/33.webp', 100, 1),
(5, '布丁奶茶/中杯', '嫩滑布丁', 9.00, 'images/34.webp', 100, 1),
(5, '奶茶三兄弟/大杯', '三种料', 13.00, 'images/35.webp', 100, 1),
(5, '奶茶三兄弟/中杯', '三种料', 11.00, 'images/36.webp', 100, 1),
(5, '双拼奶茶/大杯', '双倍快乐', 12.00, 'images/37.webp', 100, 1),
(5, '双拼奶茶/中杯', '双倍快乐', 10.00, 'images/38.webp', 100, 1),
(5, '红豆奶茶/大杯', '香甜红豆', 12.00, 'images/39.webp', 100, 1),
(5, '红豆奶茶/中杯', '香甜红豆', 10.00, 'images/40.webp', 100, 1),
(5, 'QQ奶茶/大杯', 'Q弹爽滑', 12.00, 'images/41.webp', 100, 1),
(5, 'QQ奶茶/中杯', 'Q弹爽滑', 10.00, 'images/42.webp', 100, 1),
(5, '椰果奶茶/大杯', '椰香浓郁', 11.00, 'images/43.webp', 100, 1),
(5, '椰果奶茶/中杯', '椰香浓郁', 9.00, 'images/44.webp', 100, 1),
(5, '仙草冻奶茶/大杯', '清热仙草', 11.00, 'images/45.webp', 100, 1),
(5, '仙草冻奶茶/中杯', '清热仙草', 9.00, 'images/46.webp', 100, 1),
(5, '铁观音珍珠奶茶/大杯', '茶香四溢', 12.00, 'images/47.webp', 100, 1),
(5, '琥珀珍珠奶茶大杯', 'Q弹珍珠', 12.00, 'images/48.webp', 100, 1),

-- 主食 (category_id = 6)
(6, '奶香糯玉米松饼', '松软香甜', 10.00, 'images/49.jpg', 100, 1),
(6, '红糖酥饼', '香甜酥脆', 10.00, 'images/50.jpg', 100, 1),

-- 小炒菜 (category_id = 7)
(7, '耗油青菜小炒/大份', '清爽健康', 12.00, 'images/51.jpg', 100, 1),
(7, '耗油青菜小炒/小份', '清爽健康', 10.00, 'images/52.jpg', 100, 1),
(7, '鸡蛋木耳小炒/大份', '营养丰富', 12.00, 'images/53.jpg', 100, 1),
(7, '鸡蛋木耳小炒/小份', '营养丰富', 10.00, 'images/54.jpg', 100, 1),
(7, '可乐鸡翅', '香脆可乐味', 11.00, 'images/55.jpg', 100, 1),
(7, '油菜沙拉/大份', '新鲜蔬菜', 11.00, 'images/56.jpg', 100, 1),
(7, '油菜沙拉/小份', '新鲜蔬菜', 9.00, 'images/57.jpg', 100, 1),

-- 现磨咖啡 (category_id = 8)
(8, '美式咖啡/中杯', '纯正咖啡', 8.00, 'images/58.webp', 100, 1),
(8, '香柠咖啡/大杯', '柠檬清香', 14.00, 'images/59.webp', 100, 1),
(8, '拿铁咖啡/大杯', '奶泡绵密', 16.00, 'images/60.webp', 100, 1),
(8, '拿铁咖啡/中杯', '奶泡绵密', 13.00, 'images/61.webp', 100, 1),
(8, '卡布奇诺/大杯', '经典咖啡', 16.00, 'images/62.webp', 100, 1),
(8, '卡布奇诺/中杯', '经典咖啡', 13.00, 'images/63.webp', 100, 1),
(8, '摩卡咖啡/大杯', '巧克力风味', 19.00, 'images/64.webp', 100, 1),
(8, '摩卡咖啡/中杯', '巧克力风味', 16.00, 'images/65.webp', 100, 1),
(8, '珍珠拿铁/大杯', '咖啡+珍珠', 16.00, 'images/66.webp', 100, 1),
(8, '香草拿铁/大杯', '香草甜香', 19.00, 'images/67.webp', 100, 1),
(8, '香草拿铁/中杯', '香草甜香', 16.00, 'images/68.webp', 100, 1),
(8, '法式奶霜咖啡/大杯', '奶霜绵密', 15.00, 'images/69.webp', 100, 1),
(8, '海盐焦糖拿铁/大杯', '焦糖海盐', 18.00, 'images/70.webp', 100, 1),
(8, '海盐焦糖拿铁/中杯', '焦糖海盐', 15.00, 'images/71.webp', 100, 1),
(8, '香柠咖啡', '柠檬清香', 14.00, 'images/72.webp', 100, 1),

-- 鲜果奶茶 (category_id = 9)
(9, '法式奶霜草莓果茶（大杯）', '草莓香甜', 15.00, 'images/73.webp', 100, 1),
(9, '鲜百香双响炮/大杯', '百香果双倍', 13.00, 'images/74.webp', 100, 1),
(9, '柠檬霸/大杯', '柠檬超大杯', 13.00, 'images/75.webp', 100, 1),
(9, '金桔柠檬汁/中杯', '金桔柠檬', 11.00, 'images/76.webp', 100, 1),
(9, '葡萄柚绿茶/中杯', '葡萄柚绿茶', 11.00, 'images/77.webp', 100, 1),
(9, '草莓果茶/中杯', '草莓果香', 10.00, 'images/78.webp', 100, 1),
(9, '鲜柠檬红茶/中杯', '柠檬红茶', 10.00, 'images/79.webp', 100, 1),
(9, '鲜柠檬绿茶/中杯', '柠檬绿茶', 10.00, 'images/80.webp', 100, 1),
(9, '鲜百香绿茶/中杯', '百香果绿茶', 10.00, 'images/81.webp', 100, 1);

-- ----------------------------
-- 促销/轮播图数据
-- ----------------------------
INSERT INTO `promotion` (`title`, `image`, `link`, `status`) VALUES
('新用户首单立减20元', '/promo/1.jpg', '', 1),
('满50减10', '/promo/2.jpg', '', 1),
('新品上市', '/promo/3.jpg', '', 1);
