package com.foodie.order.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 菜品图片：/images/** -> static/images/
        registry.addResourceHandler("/images/**")
                .addResourceLocations("classpath:/static/images/");
        
        // 分类图标：/category/** -> static/category/
        registry.addResourceHandler("/category/**")
                .addResourceLocations("classpath:/static/category/");
        
        // 轮播图：/promo/** -> static/promo/
        registry.addResourceHandler("/promo/**")
                .addResourceLocations("classpath:/static/promo/");
    }
}
