package com.foodie.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foodie.order.entity.Promotion;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PromotionMapper extends BaseMapper<Promotion> {
}
