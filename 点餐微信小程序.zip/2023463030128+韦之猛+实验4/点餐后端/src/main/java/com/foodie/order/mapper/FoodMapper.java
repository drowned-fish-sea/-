package com.foodie.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foodie.order.entity.Food;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FoodMapper extends BaseMapper<Food> {
}
