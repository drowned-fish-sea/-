package com.foodie.order.controller;

import com.foodie.order.entity.User;
import com.foodie.order.service.FoodService;
import com.foodie.order.service.ReviewService;
import com.foodie.order.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/food")
@CrossOrigin(origins = "*")
public class FoodController {
    
    @Autowired
    private FoodService foodService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private ReviewService reviewService;
    
    /**
     * 获取首页数据
     */
    @GetMapping("/index")
    public Map<String, Object> getIndex() {
        return foodService.getIndexData();
    }
    
    /**
     * 获取菜品列表
     */
    @GetMapping("/list")
    public Map<String, Object> getFoodList() {
        return foodService.getFoodList();
    }
    
    /**
     * 获取订单详情或创建/更新订单
     */
    @RequestMapping(value = "/order", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String, Object> order(
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String comment,
            @RequestBody(required = false) Object body,
            HttpServletRequest request) {
        
        Long userId = getUserId(request);
        if (userId == null) {
            Map<String, Object> result = new HashMap<>();
            result.put("code", 0);
            result.put("msg", "请先登录");
            return result;
        }
        
        // GET 请求 - 获取订单详情
        if ("GET".equalsIgnoreCase(request.getMethod())) {
            if (id != null) {
                return foodService.getOrderDetail(userId, Long.parseLong(id));
            }
            return new HashMap<>();
        }
        
        // POST 请求
        String orderId = id;
        String orderComment = comment;
        
        // 从 JSON body 中获取 id 和 comment
        if (body != null && (orderId == null || orderComment == null)) {
            if (body instanceof java.util.Map) {
                @SuppressWarnings("unchecked")
                java.util.Map<String, Object> bodyMap = (java.util.Map<String, Object>) body;
                if (orderId == null) {
                    Object bodyId = bodyMap.get("id");
                    if (bodyId != null) {
                        orderId = bodyId.toString();
                    }
                }
                if (orderComment == null) {
                    orderComment = (String) bodyMap.get("comment");
                }
            }
        }
        
        // 如果有 id，更新订单备注
        if (orderId != null) {
            return foodService.updateOrderComment(userId, Long.parseLong(orderId), orderComment);
        }
        
        // 没有 id，检查是否创建订单（body 是数组）
        if (body instanceof java.util.List) {
            @SuppressWarnings("unchecked")
            java.util.List<java.util.Map<String, Object>> cartList = (java.util.List<java.util.Map<String, Object>>) body;
            return foodService.createOrder(userId, null, comment, cartList);
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("code", 0);
        result.put("msg", "参数错误");
        return result;
    }
    
    /**
     * 支付订单
     */
    @PostMapping("/pay")
    public Map<String, Object> pay(
            @RequestParam(required = false) String id,
            @RequestBody(required = false) Map<String, Object> body,
            HttpServletRequest request) {
        
        Long userId = getUserId(request);
        if (userId == null) {
            Map<String, Object> result = new HashMap<>();
            result.put("code", 0);
            result.put("msg", "请先登录");
            return result;
        }
        
        // 从 body 中获取 id
        String orderId = id;
        if (orderId == null && body != null) {
            Object bodyId = body.get("id");
            if (bodyId != null) {
                orderId = bodyId.toString();
            }
        }
        
        if (orderId == null) {
            Map<String, Object> result = new HashMap<>();
            result.put("code", 0);
            result.put("msg", "订单ID不能为空");
            return result;
        }
        
        return foodService.payOrder(userId, Long.parseLong(orderId));
    }
    
    /**
     * 获取待出餐订单（商家管理）
     */
    @GetMapping("/admin/pending-orders")
    public Map<String, Object> getPendingOrders(HttpServletRequest request) {
        return foodService.getPendingOrders();
    }
    
    /**
     * 出餐（商家操作）
     */
    @PostMapping("/ready")
    public Map<String, Object> ready(
            @RequestParam(required = false) String id,
            @RequestBody(required = false) Map<String, Object> body,
            HttpServletRequest request) {
        
        // 出餐接口不需要登录验证（商家端使用）
        
        // 从 body 中获取 id
        String orderId = id;
        if (orderId == null && body != null) {
            Object bodyId = body.get("id");
            if (bodyId != null) {
                orderId = bodyId.toString();
            }
        }
        
        if (orderId == null) {
            Map<String, Object> result = new HashMap<>();
            result.put("code", 0);
            result.put("msg", "订单ID不能为空");
            return result;
        }
        
        return foodService.readyOrder(Long.parseLong(orderId));
    }
    
    /**
     * 获取订单列表
     */
    @GetMapping("/orderlist")
    public Map<String, Object> getOrderList(
            @RequestParam(defaultValue = "0") Long last_id,
            @RequestParam(defaultValue = "10") Integer row,
            HttpServletRequest request) {
        
        Long userId = getUserId(request);
        if (userId == null) {
            Map<String, Object> result = new HashMap<>();
            result.put("code", 0);
            result.put("msg", "请先登录");
            return result;
        }
        
        return foodService.getOrderList(userId, last_id, row);
    }
    
    /**
     * 获取用户消费记录
     */
    @GetMapping("/record")
    public Map<String, Object> getRecord(HttpServletRequest request) {
        Long userId = getUserId(request);
        if (userId == null) {
            Map<String, Object> result = new HashMap<>();
            result.put("code", 0);
            result.put("msg", "请先登录");
            return result;
        }
        
        return foodService.getUserRecord(userId);
    }
    
    /**
     * 提交评价
     */
    @PostMapping("/review")
    public Map<String, Object> addReview(
            @RequestParam(required = false) Long orderId,
            @RequestParam(required = false) Long foodId,
            @RequestParam(required = false) Integer rating,
            @RequestParam(required = false) String comment,
            @RequestBody(required = false) Map<String, Object> body,
            HttpServletRequest request) {
        
        // 从 body 中获取参数（如果前端发送 JSON）
        if (body != null) {
            if (orderId == null && body.get("orderId") != null) {
                orderId = Long.parseLong(body.get("orderId").toString());
            }
            if (foodId == null && body.get("foodId") != null) {
                foodId = Long.parseLong(body.get("foodId").toString());
            }
            if (rating == null && body.get("rating") != null) {
                rating = Integer.parseInt(body.get("rating").toString());
            }
            if (comment == null && body.get("comment") != null) {
                comment = body.get("comment").toString();
            }
        }
        
        Long userId = getUserId(request);
        return reviewService.addReview(userId, orderId, foodId, rating, comment);
    }
    
    /**
     * 获取菜品评分列表（按平均分从高到低）
     */
    @GetMapping("/ratings")
    public Map<String, Object> getFoodRatings() {
        return reviewService.getFoodRatings();
    }
    
    /**
     * 获取菜品的所有评价
     */
    @GetMapping("/reviews")
    public Map<String, Object> getFoodReviews(@RequestParam(required = false) Long foodId) {
        return reviewService.getFoodReviews(foodId);
    }
    
    /**
     * 从 Cookie 获取用户 ID
     */
    private Long getUserId(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("sessionId".equals(cookie.getName())) {
                    User user = userService.getCurrentUser(cookie.getValue());
                    if (user != null) {
                        return user.getId();
                    }
                }
            }
        }
        return null;
    }
}
