package com.foodie.order.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foodie.order.entity.*;
import com.foodie.order.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class FoodService {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * 格式化日期时间为字符串
     */
    private String formatDateTime(Date date) {
        if (date == null) {
            // 如果日期为 null，返回当前时间
            return DATE_FORMAT.format(new Date());
        }
        return DATE_FORMAT.format(date);
    }

    @Autowired
    private FoodMapper foodMapper;

    @Autowired
    private CategoryMapper categoryMapper;

    @Autowired
    private PromotionMapper promotionMapper;

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private OrderItemMapper orderItemMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private UserService userService;

    /**
     * 获取首页数据
     */
    public Map<String, Object> getIndexData() {
        Map<String, Object> result = new HashMap<>();

        // 轮播图（使用促销图作为轮播图）
        LambdaQueryWrapper<Promotion> promoWrapper = new LambdaQueryWrapper<>();
        promoWrapper.eq(Promotion::getStatus, 1);
        promoWrapper.orderByDesc(Promotion::getCreateTime);
        List<Promotion> promotions = promotionMapper.selectList(promoWrapper);

        List<String> swiperImages = promotions.stream()
                .map(Promotion::getImage)
                .collect(Collectors.toList());

        // 广告图（第一张促销图）
        String adImage = promotions.isEmpty() ? "" : promotions.get(0).getImage();

        // 分类
        LambdaQueryWrapper<Category> catWrapper = new LambdaQueryWrapper<>();
        catWrapper.orderByAsc(Category::getSort);
        List<Category> categories = categoryMapper.selectList(catWrapper);

        List<Map<String, Object>> categoryList = categories.stream().map(cat -> {
            Map<String, Object> catMap = new HashMap<>();
            catMap.put("id", cat.getId());
            catMap.put("name", cat.getName());
            catMap.put("icon", cat.getIcon());
            return catMap;
        }).collect(Collectors.toList());

        result.put("img_swiper", swiperImages);
        result.put("img_ad", adImage);
        result.put("img_category", categoryList);

        return result;
    }

    /**
     * 获取菜品列表
     */
    public Map<String, Object> getFoodList() {
        Map<String, Object> result = new HashMap<>();

        // 查询所有分类
        LambdaQueryWrapper<Category> catWrapper = new LambdaQueryWrapper<>();
        catWrapper.orderByAsc(Category::getSort);
        List<Category> categories = categoryMapper.selectList(catWrapper);

        // 按分类组装菜品列表
        List<Map<String, Object>> foodCategoryList = new ArrayList<>();

        for (Category category : categories) {
            LambdaQueryWrapper<Food> foodWrapper = new LambdaQueryWrapper<>();
            foodWrapper.eq(Food::getCategoryId, category.getId());
            foodWrapper.eq(Food::getStatus, 1);
            List<Food> foods = foodMapper.selectList(foodWrapper);

            List<Map<String, Object>> foodItems = foods.stream().map(food -> {
                Map<String, Object> foodMap = new HashMap<>();
                foodMap.put("id", food.getId());
                foodMap.put("name", food.getName());
                foodMap.put("description", food.getDescription());
                foodMap.put("price", food.getPrice());
                foodMap.put("image", food.getImage());
                foodMap.put("stock", food.getStock());
                return foodMap;
            }).collect(Collectors.toList());

            Map<String, Object> categoryItem = new HashMap<>();
            categoryItem.put("name", category.getName());
            categoryItem.put("food", foodItems);
            foodCategoryList.add(categoryItem);
        }

        result.put("list", foodCategoryList);

        // 促销活动
        LambdaQueryWrapper<Promotion> promoWrapper = new LambdaQueryWrapper<>();
        promoWrapper.eq(Promotion::getStatus, 1);
        promoWrapper.last("LIMIT 1");
        Promotion promotion = promotionMapper.selectOne(promoWrapper);

        List<Map<String, Object>> promotionList = new ArrayList<>();
        if (promotion != null) {
            Map<String, Object> promoMap = new HashMap<>();
            promoMap.put("title", promotion.getTitle());
            promoMap.put("image", promotion.getImage());
            promoMap.put("link", promotion.getLink());
            promotionList.add(promoMap);
        }
        result.put("promotion", promotionList);

        return result;
    }

    /**
     * 创建/更新订单
     */
    public Map<String, Object> createOrder(Long userId, String orderId, String comment, List<Map<String, Object>> cartItems) {
        Map<String, Object> result = new HashMap<>();

        if (cartItems == null || cartItems.isEmpty()) {
            result.put("code", 0);
            result.put("msg", "购物车为空");
            return result;
        }

        // 先计算总价
        BigDecimal totalPrice = BigDecimal.ZERO;
        List<Map<String, Object>> validItems = new ArrayList<>();

        for (Map<String, Object> item : cartItems) {
            Long foodId = Long.parseLong(item.get("id").toString());
            Integer number = Integer.parseInt(item.get("number").toString());

            Food food = foodMapper.selectById(foodId);
            if (food != null) {
                validItems.add(item);
                totalPrice = totalPrice.add(food.getPrice().multiply(BigDecimal.valueOf(number)));
            }
        }

        // 生成订单号
        String orderNo = "O" + System.currentTimeMillis();

        Order order;
        if (orderId != null && !orderId.isEmpty()) {
            // 更新现有订单
            order = orderMapper.selectById(Long.parseLong(orderId));
            if (order == null) {
                result.put("code", 0);
                result.put("msg", "订单不存在");
                return result;
            }
            // 删除旧的订单项
            LambdaQueryWrapper<OrderItem> itemWrapper = new LambdaQueryWrapper<>();
            itemWrapper.eq(OrderItem::getOrderId, order.getId());
            orderItemMapper.delete(itemWrapper);
        } else {
            // 创建新订单
            order = new Order();
            order.setOrderNo(orderNo);
            order.setUserId(userId);
            order.setTotalPrice(totalPrice); // 先设置总价
            order.setStatus(0); // 待支付
            order.setCreateTime(new Date());
            order.setUpdateTime(new Date());
            orderMapper.insert(order);
        }

        // 添加订单项
        for (Map<String, Object> item : validItems) {
            Long foodId = Long.parseLong(item.get("id").toString());
            Integer number = Integer.parseInt(item.get("number").toString());

            Food food = foodMapper.selectById(foodId);
            if (food != null) {
                OrderItem orderItem = new OrderItem();
                orderItem.setOrderId(order.getId());
                orderItem.setFoodId(foodId);
                orderItem.setFoodName(food.getName());
                orderItem.setQuantity(number);
                orderItem.setPrice(food.getPrice().intValue());
                orderItemMapper.insert(orderItem);
            }
        }

        // 更新订单总价
        order.setTotalPrice(totalPrice);
        order.setUpdateTime(new Date());
        orderMapper.updateById(order);

        result.put("id", order.getId());
        result.put("orderNo", order.getOrderNo());
        result.put("totalPrice", totalPrice);
        result.put("code", 1);

        return result;
    }

    /**
     * 获取订单详情
     */
    public Map<String, Object> getOrderDetail(Long userId, Long orderId) {
        Map<String, Object> result = new HashMap<>();

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            result.put("code", 0);
            result.put("msg", "订单不存在");
            return result;
        }

        // 查询订单项
        LambdaQueryWrapper<OrderItem> itemWrapper = new LambdaQueryWrapper<>();
        itemWrapper.eq(OrderItem::getOrderId, orderId);
        List<OrderItem> items = orderItemMapper.selectList(itemWrapper);

        List<Map<String, Object>> orderItems = items.stream().map(item -> {
            Map<String, Object> itemMap = new HashMap<>();
            itemMap.put("id", item.getId());
            itemMap.put("food_id", item.getFoodId()); // 前端期望 food_id
            itemMap.put("name", item.getFoodName());
            itemMap.put("number", item.getQuantity());
            itemMap.put("price", item.getPrice());
            // 获取菜品图片
            Food food = foodMapper.selectById(item.getFoodId());
            if (food != null) {
                itemMap.put("image_url", food.getImage());
            }
            return itemMap;
        }).collect(Collectors.toList());

        // 生成取餐码（订单ID后4位）
        String code = String.format("%04d", order.getId() % 10000);

        result.put("id", order.getId());
        result.put("sn", order.getOrderNo());  // 订单号
        result.put("order_code", code);  // 取餐码（避免与code字段冲突）
        result.put("is_taken", order.getStatus() == 2);  // 是否已取餐
        result.put("status", order.getStatus());
        result.put("comment", order.getComment());
        result.put("items", orderItems);
        // 前端期望的字段名
        result.put("order_food", orderItems);
        result.put("price", order.getTotalPrice());
        result.put("create_time", formatDateTime(order.getCreateTime()));
        result.put("pay_time", formatDateTime(order.getPayTime()));
        result.put("code", 1);

        return result;
    }

    /**
     * 支付订单
     */
    public Map<String, Object> payOrder(Long userId, Long orderId) {
        Map<String, Object> result = new HashMap<>();

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            result.put("code", 0);
            result.put("msg", "订单不存在");
            return result;
        }

        if (order.getStatus() != 0) {
            result.put("code", 0);
            result.put("msg", "订单状态异常");
            return result;
        }

        // 更新订单状态为已支付
        order.setStatus(1);
        order.setPayTime(new Date());
        order.setUpdateTime(new Date());
        orderMapper.updateById(order);

        result.put("code", 1);
        result.put("msg", "支付成功");

        return result;
    }

    /**
     * 出餐（标记订单已完成）
     */
    public Map<String, Object> readyOrder(Long orderId) {
        Map<String, Object> result = new HashMap<>();

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            result.put("code", 0);
            result.put("msg", "订单不存在");
            return result;
        }

        if (order.getStatus() != 1) {
            result.put("code", 0);
            result.put("msg", "只有已支付的订单才能出餐");
            return result;
        }

        // 更新订单状态为已出餐
        order.setStatus(2);
        order.setUpdateTime(new Date());
        orderMapper.updateById(order);

        result.put("code", 1);
        result.put("msg", "出餐成功");

        return result;
    }

    /**
     * 获取待出餐订单（商家管理）
     */
    public Map<String, Object> getPendingOrders() {
        Map<String, Object> result = new HashMap<>();

        // 查询所有已支付(status=1)但未出餐(status=2)的订单
        LambdaQueryWrapper<Order> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Order::getStatus, 1); // 已支付
        wrapper.orderByAsc(Order::getCreateTime); // 按创建时间升序，先下单的先出餐

        List<Order> orders = orderMapper.selectList(wrapper);

        List<Map<String, Object>> orderList = new ArrayList<>();
        for (Order order : orders) {
            Map<String, Object> orderMap = new HashMap<>();
            orderMap.put("id", order.getId());
            orderMap.put("orderNo", order.getOrderNo());
            orderMap.put("totalPrice", order.getTotalPrice());
            orderMap.put("status", order.getStatus());
            orderMap.put("createTime", formatDateTime(order.getCreateTime()));

            // 查询订单项
            LambdaQueryWrapper<OrderItem> itemWrapper = new LambdaQueryWrapper<>();
            itemWrapper.eq(OrderItem::getOrderId, order.getId());
            List<OrderItem> items = orderItemMapper.selectList(itemWrapper);

            List<Map<String, Object>> itemList = items.stream().map(item -> {
                Map<String, Object> itemMap = new HashMap<>();
                itemMap.put("id", item.getId());
                itemMap.put("name", item.getFoodName());
                itemMap.put("quantity", item.getQuantity());
                itemMap.put("price", item.getPrice());
                // 获取菜品图片
                Food food = foodMapper.selectById(item.getFoodId());
                if (food != null) {
                    itemMap.put("image_url", food.getImage());
                }
                return itemMap;
            }).collect(Collectors.toList());

            orderMap.put("items", itemList);
            orderList.add(orderMap);
        }

        result.put("orders", orderList);
        result.put("code", 1);

        return result;
    }

    /**
     * 获取订单列表
     */
    public Map<String, Object> getOrderList(Long userId, Long lastId, Integer row) {
        Map<String, Object> result = new HashMap<>();

        LambdaQueryWrapper<Order> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Order::getUserId, userId);
        wrapper.orderByDesc(Order::getCreateTime);

        if (lastId != null && lastId > 0) {
            wrapper.lt(Order::getId, lastId);
        }
        wrapper.last("LIMIT " + row);

        List<Order> orders = orderMapper.selectList(wrapper);

        List<Map<String, Object>> orderList = new ArrayList<>();
        for (Order order : orders) {
            Map<String, Object> orderMap = new HashMap<>();
            orderMap.put("id", order.getId());
            orderMap.put("orderNo", order.getOrderNo());
            orderMap.put("price", order.getTotalPrice()); // 前端期望 price
            orderMap.put("status", order.getStatus());
            // 格式化时间为字符串，前端期望 create_time
            orderMap.put("create_time", formatDateTime(order.getCreateTime()));

            // 查询订单项
            LambdaQueryWrapper<OrderItem> itemWrapper = new LambdaQueryWrapper<>();
            itemWrapper.eq(OrderItem::getOrderId, order.getId());
            List<OrderItem> items = orderItemMapper.selectList(itemWrapper);

            // 第一道菜名，前端期望 first_food_name
            List<String> foodNames = items.stream()
                    .map(OrderItem::getFoodName)
                    .collect(Collectors.toList());
            orderMap.put("first_food_name", foodNames.isEmpty() ? "" : foodNames.get(0));

            // 总数量，前端期望 number
            int totalNum = items.stream().mapToInt(OrderItem::getQuantity).sum();
            orderMap.put("number", totalNum);

            orderList.add(orderMap);
        }

        result.put("list", orderList);
        result.put("last_id", orders.isEmpty() ? lastId : orders.get(orders.size() - 1).getId());
        result.put("code", 1);

        return result;
    }

    /**
     * 获取用户消费记录
     */
    public Map<String, Object> getUserRecord(Long userId) {
        Map<String, Object> result = new HashMap<>();

        // 使用传入的 userId 查询用户信息
        if (userId != null) {
            User user = userMapper.selectById(userId);
            if (user != null) {
                result.put("nickname", user.getNickname());
                result.put("avatarUrl", user.getAvatarUrl());
            } else {
                result.put("nickname", "游客");
                result.put("avatarUrl", "/images/avatar.png");
            }
        } else {
            result.put("nickname", "游客");
            result.put("avatarUrl", "/images/avatar.png");
        }

        if (userId == null) {
            result.put("totalAmount", 0);
            result.put("orderCount", 0);
            result.put("list", new ArrayList<>());
            result.put("code", 1);
            return result;
        }

        // 查询已支付的订单（包括已取餐的订单，status >= 1）
        LambdaQueryWrapper<Order> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Order::getUserId, userId);
        wrapper.ge(Order::getStatus, 1); // 已支付或已取餐的订单
        wrapper.orderByDesc(Order::getPayTime); // 按支付时间降序

        List<Order> paidOrders = orderMapper.selectList(wrapper);

        BigDecimal totalAmount = paidOrders.stream()
                .filter(o -> o.getTotalPrice() != null)
                .map(Order::getTotalPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        result.put("totalAmount", totalAmount);
        result.put("orderCount", paidOrders.size());

        // 构建消费记录列表
        List<Map<String, Object>> recordList = new ArrayList<>();
        for (Order order : paidOrders) {
            Map<String, Object> record = new HashMap<>();
            record.put("id", order.getId());
            record.put("price", order.getTotalPrice());
            record.put("pay_time", formatDateTime(order.getPayTime()));
            recordList.add(record);
        }
        result.put("list", recordList);

        result.put("code", 1);

        return result;
    }

    /**
     * 更新订单备注
     */
    public Map<String, Object> updateOrderComment(Long userId, Long orderId, String comment) {
        Map<String, Object> result = new HashMap<>();

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            result.put("code", 0);
            result.put("msg", "订单不存在");
            return result;
        }

        // 更新备注
        order.setComment(comment);
        order.setUpdateTime(new Date());
        orderMapper.updateById(order);

        result.put("code", 1);
        return result;
    }
}
