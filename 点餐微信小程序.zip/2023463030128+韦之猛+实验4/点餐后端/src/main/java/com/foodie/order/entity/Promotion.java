package com.foodie.order.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.util.Date;

@Data
@TableName("promotion")
public class Promotion {
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String title;
    
    private String image;
    
    private String link;
    
    private Integer status;
    
    private Date createTime;
    
    @TableLogic
    private Integer deleted;
}
