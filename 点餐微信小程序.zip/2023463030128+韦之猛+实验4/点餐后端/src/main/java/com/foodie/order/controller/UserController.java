package com.foodie.order.controller;

import com.foodie.order.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "*")
public class UserController {
    
    @Autowired
    private UserService userService;
    
    /**
     * 检查登录状态
     */
    @GetMapping("/checkLogin")
    public Map<String, Object> checkLogin(HttpServletRequest request) {
        String sessionId = getSessionId(request);
        return userService.checkLogin(sessionId);
    }
    
    /**
     * 微信登录
     */
    @GetMapping("/login")
    public Map<String, Object> login(
            @RequestParam String js_code,
            HttpServletRequest request,
            HttpServletResponse response) {
        
        Map<String, Object> loginResult = userService.login(js_code);
        
        if (loginResult.get("code") != null && ((Number) loginResult.get("code")).intValue() == 1) {
            // 设置 Cookie
            String sessionId = (String) loginResult.get("sessionId");
            Cookie cookie = new Cookie("sessionId", sessionId);
            cookie.setPath("/");
            cookie.setMaxAge(7 * 24 * 60 * 60); // 7天
            response.addCookie(cookie);
        }
        
        return loginResult;
    }
    
    /**
     * 获取 sessionId
     */
    private String getSessionId(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("sessionId".equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}
