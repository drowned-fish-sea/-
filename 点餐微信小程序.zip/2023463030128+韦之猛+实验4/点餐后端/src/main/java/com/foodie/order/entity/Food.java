package com.foodie.order.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.math.BigDecimal;
import java.util.Date;

@Data
@TableName("food")
public class Food {
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long categoryId;
    
    private String name;
    
    private String description;
    
    private BigDecimal price;
    
    private String image;
    
    private Integer stock;
    
    private Integer status; // 0:下架 1:上架
    
    private Date createTime;
    
    @TableLogic
    private Integer deleted;
}
