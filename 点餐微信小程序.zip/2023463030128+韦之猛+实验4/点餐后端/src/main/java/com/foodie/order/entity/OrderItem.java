package com.foodie.order.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

@Data
@TableName("order_item")
public class OrderItem {
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long orderId;
    
    private Long foodId;
    
    private String foodName;
    
    private Integer quantity;
    
    private Integer price;
    
    @TableLogic
    private Integer deleted;
}
