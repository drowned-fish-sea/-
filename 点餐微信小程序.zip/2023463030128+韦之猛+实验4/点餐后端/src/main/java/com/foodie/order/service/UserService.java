package com.foodie.order.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foodie.order.entity.User;
import com.foodie.order.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class UserService {
    
    @Autowired
    private UserMapper userMapper;
    
    // 内存存储 session
    private Map<String, Long> memorySession = new ConcurrentHashMap<>();
    
    @PostConstruct
    public void init() {
        System.out.println("========================================");
        System.out.println("UserService 初始化完成（使用内存存储）");
        System.out.println("========================================");
    }
    
    /**
     * 微信登录
     */
    public Map<String, Object> login(String jsCode) {
        Map<String, Object> result = new HashMap<>();
        
        String openid = getOpenidFromWx(jsCode);
        if (openid == null) {
            result.put("code", 0);
            result.put("msg", "登录失败");
            return result;
        }
        
        User user = getOrCreateUser(openid);
        
        // 生成 session
        String sessionId = java.util.UUID.randomUUID().toString().replace("-", "");
        saveSession(sessionId, user.getId());
        
        result.put("code", 1);
        result.put("sessionId", sessionId);
        result.put("user", user);
        
        return result;
    }
    
    /**
     * 检查登录状态
     */
    public Map<String, Object> checkLogin(String sessionId) {
        Map<String, Object> result = new HashMap<>();
        
        if (sessionId == null || sessionId.isEmpty()) {
            result.put("code", 0);
            result.put("msg", "未登录");
            return result;
        }
        
        Long userId = getUserIdFromSession(sessionId);
        if (userId == null) {
            result.put("code", 0);
            result.put("msg", "登录已过期");
            return result;
        }
        
        User user = userMapper.selectById(userId);
        if (user == null) {
            result.put("code", 0);
            result.put("msg", "用户不存在");
            return result;
        }
        
        result.put("code", 1);
        result.put("user", user);
        
        return result;
    }
    
    /**
     * 获取当前登录用户
     */
    public User getCurrentUser(String sessionId) {
        if (sessionId == null || sessionId.isEmpty()) {
            return null;
        }
        
        Long userId = getUserIdFromSession(sessionId);
        if (userId == null) {
            return null;
        }
        
        return userMapper.selectById(userId);
    }
    
    /**
     * 获取或创建用户
     */
    private User getOrCreateUser(String openid) {
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getOpenid, openid);
        User user = userMapper.selectOne(wrapper);
        
        if (user == null) {
            user = new User();
            user.setOpenid(openid);
            user.setNickname("用户" + openid.substring(0, Math.min(8, openid.length())));
            user.setAvatarUrl("/images/avatar.png");
            userMapper.insert(user);
        }
        
        return user;
    }
    
    /**
     * 保存 session
     */
    private void saveSession(String sessionId, Long userId) {
        memorySession.put(sessionId, userId);
    }
    
    /**
     * 从 session 获取用户ID
     */
    private Long getUserIdFromSession(String sessionId) {
        return memorySession.get(sessionId);
    }
    
    /**
     * 模拟获取微信 openid
     * 实际项目中需要调用微信接口
     */
    private String getOpenidFromWx(String jsCode) {
        if (jsCode != null && !jsCode.isEmpty()) {
            return "openid_" + Math.abs(jsCode.hashCode());
        }
        return null;
    }
}
