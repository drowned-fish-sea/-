package com.foodie.order.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foodie.order.entity.Food;
import com.foodie.order.entity.Order;
import com.foodie.order.entity.Review;
import com.foodie.order.mapper.FoodMapper;
import com.foodie.order.mapper.OrderMapper;
import com.foodie.order.mapper.ReviewMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ReviewService {
    
    @Autowired
    private ReviewMapper reviewMapper;
    
    @Autowired
    private FoodMapper foodMapper;
    
    @Autowired
    private OrderMapper orderMapper;
    
    /**
     * 提交评价
     */
    public Map<String, Object> addReview(Long userId, Long orderId, Long foodId, Integer rating, String comment) {
        Map<String, Object> result = new HashMap<>();
        
        // 参数校验
        if (orderId == null) {
            result.put("code", 0);
            result.put("msg", "订单ID不能为空");
            return result;
        }
        
        if (foodId == null) {
            result.put("code", 0);
            result.put("msg", "菜品ID不能为空");
            return result;
        }
        
        if (rating == null || rating < 1 || rating > 5) {
            result.put("code", 0);
            result.put("msg", "评分必须是1-5星");
            return result;
        }
        
        // 验证订单是否属于该用户且已支付
        if (userId != null) {
            Order order = orderMapper.selectById(orderId);
            if (order == null) {
                result.put("code", 0);
                result.put("msg", "订单不存在");
                return result;
            }
            if (!order.getUserId().equals(userId)) {
                result.put("code", 0);
                result.put("msg", "无权评价此订单");
                return result;
            }
            if (order.getStatus() < 1) {
                result.put("code", 0);
                result.put("msg", "订单未支付，无法评价");
                return result;
            }
        }
        
        // 检查是否已评价过
        LambdaQueryWrapper<Review> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Review::getOrderId, orderId);
        wrapper.eq(Review::getFoodId, foodId);
        if (userId != null) {
            wrapper.eq(Review::getUserId, userId);
        }
        Review existingReview = reviewMapper.selectOne(wrapper);
        
        if (existingReview != null) {
            // 更新评价
            existingReview.setRating(rating);
            existingReview.setComment(comment);
            existingReview.setUpdateTime(new Date());
            reviewMapper.updateById(existingReview);
            result.put("msg", "评价已更新");
        } else {
            // 新增评价
            Review review = new Review();
            review.setOrderId(orderId);
            review.setUserId(userId != null ? userId : 0L);
            review.setFoodId(foodId);
            review.setRating(rating);
            review.setComment(comment);
            review.setCreateTime(new Date());
            review.setUpdateTime(new Date());
            reviewMapper.insert(review);
            result.put("msg", "评价成功");
        }
        
        result.put("code", 1);
        return result;
    }
    
    /**
     * 获取菜品评分列表（按平均分从高到低）
     */
    public Map<String, Object> getFoodRatings() {
        Map<String, Object> result = new HashMap<>();
        
        // 查询所有有评价的菜品及其评分
        List<Map<String, Object>> foodRatings = new ArrayList<>();
        
        // 获取所有菜品
        List<Food> allFoods = foodMapper.selectList(null);
        
        for (Food food : allFoods) {
            LambdaQueryWrapper<Review> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Review::getFoodId, food.getId());
            
            List<Review> reviews = reviewMapper.selectList(wrapper);
            
            if (reviews.isEmpty()) {
                continue; // 跳过没有评价的菜品
            }
            
            // 计算平均分
            double totalRating = reviews.stream()
                    .mapToInt(Review::getRating)
                    .sum();
            double avgRating = totalRating / reviews.size();
            
            // 四舍五入到1位小数
            avgRating = Math.round(avgRating * 10) / 10.0;
            
            Map<String, Object> item = new HashMap<>();
            item.put("id", food.getId());
            item.put("name", food.getName());
            item.put("image", food.getImage());
            item.put("avgRating", avgRating);
            item.put("reviewCount", reviews.size());
            
            foodRatings.add(item);
        }
        
        // 按平均分从高到低排序
        foodRatings.sort((a, b) -> {
            double avgA = (double) a.get("avgRating");
            double avgB = (double) b.get("avgRating");
            return Double.compare(avgB, avgA); // 降序
        });
        
        result.put("code", 1);
        result.put("list", foodRatings);
        
        return result;
    }
    
    /**
     * 获取菜品的所有评价
     */
    public Map<String, Object> getFoodReviews(Long foodId) {
        Map<String, Object> result = new HashMap<>();
        
        if (foodId == null) {
            result.put("code", 0);
            result.put("msg", "菜品ID不能为空");
            return result;
        }
        
        LambdaQueryWrapper<Review> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Review::getFoodId, foodId);
        wrapper.orderByDesc(Review::getCreateTime);
        
        List<Review> reviews = reviewMapper.selectList(wrapper);
        
        // 计算平均分
        double avgRating = 0;
        if (!reviews.isEmpty()) {
            double totalRating = reviews.stream()
                    .mapToInt(Review::getRating)
                    .sum();
            avgRating = Math.round((totalRating / reviews.size()) * 10) / 10.0;
        }
        
        result.put("code", 1);
        result.put("avgRating", avgRating);
        result.put("reviewCount", reviews.size());
        result.put("list", reviews);
        
        return result;
    }
    
    /**
     * 检查用户是否已评价某订单的某菜品
     */
    public boolean hasReviewed(Long userId, Long orderId, Long foodId) {
        LambdaQueryWrapper<Review> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Review::getOrderId, orderId);
        wrapper.eq(Review::getFoodId, foodId);
        if (userId != null) {
            wrapper.eq(Review::getUserId, userId);
        }
        return reviewMapper.selectOne(wrapper) != null;
    }
}
