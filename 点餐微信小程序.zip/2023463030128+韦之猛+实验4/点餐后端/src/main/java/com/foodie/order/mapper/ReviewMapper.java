package com.foodie.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foodie.order.entity.Review;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReviewMapper extends BaseMapper<Review> {
}
