package com.foodie.order;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;

@SpringBootApplication(exclude = {RedisAutoConfiguration.class})
@MapperScan("com.foodie.order.mapper")
public class FoodieOrderApplication {
    public static void main(String[] args) {
        SpringApplication.run(FoodieOrderApplication.class, args);
    }
}
